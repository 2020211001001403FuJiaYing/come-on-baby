package com.FuJiaYing.week5.demo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "LoginServlet",value = "/login")
public class LoginServlet extends HttpServlet {
    @Override
        public void init() throws ServletException{
        super.init();
        ///TODO 1: GET 4 CONTEXT PARAM - DRIVER , URL , USERNAME , PASSWORD
        //TODO 2: GET JDBC connection
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // TODO 3：GRT REQUESST PARAMETER - USERNAME AND PASSWORD
        //TODO 4: VALIDATE USER - SELEECT * FROM USERTABLE WHERE USERNAME='FuJiaYing'
        // and password='123456'
        // TODO 5: CHEK IF(USER IS VALID){
        //  OUT.PRINTLN("login success !!!");
        // OUT.PRINT ("welcome,username");
        //}ELSE{
        //  OUT.PRINT(LOGIN ERROR!!!);
         //}
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
