package log;

import JDBCutil.jdbcutil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/loggg")
public class logg extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter() ;
        resp.setContentType("charset=utf-8;text/html");
        String username = req.getParameter("username");
        String pass = req.getParameter("password") ;
        Connection con = null ;
        PreparedStatement ps = null ;
        ResultSet res = null ;
        int rest = 0 ;
        String password1 = null ;
        String username1 = null ;
        try {
            con = jdbcutil.getconnection() ;
            String sql4= "select count(*) from user where username = ? and password = ?";
            ps = con.prepareStatement(sql4) ;
            ps.setString(1,username);
            ps.setString(2,pass);
            res = ps.executeQuery();
            while (res.next())
            {
                rest = res.getInt("count(*)");
            }
            if (rest != 0){
                out.print("log in successfully");
            }else{
                out.print("fail account or password error!");
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            jdbcutil.close(ps,con);
        }
    }
}
