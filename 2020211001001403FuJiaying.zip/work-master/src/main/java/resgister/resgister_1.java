package resgister;

import JDBCutil.jdbcutil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutionException;

@WebServlet("/resgist1")
public class resgister_1 extends HttpServlet{
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection con = null ;
        PreparedStatement ps = null ;
        String username = req.getParameter("username");
        String password = req.getParameter("password") ;
        PrintWriter out = resp.getWriter() ;
        System.out.println(username+""+password);
        try {
            con = jdbcutil.getconnection() ;
            String sql = "insert into user(username,password) values(?,?)";
            ps = con.prepareStatement(sql) ;
            ps.setString(1,username);
            ps.setString(2,password);
            int i = ps.executeUpdate() ;
            if (i != 0){
                out.print("regist sucessfully");
            }else{
                out.print("fail");
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            jdbcutil.close(ps,con);
        }
    }
}
